# -*- coding: utf-8 -*-

__author__ = 'Andile Jaden Mbele'
__email__ = 'andilembele020@gmail.com'
__github__ = 'www.github.com/xeroxzen/pycountrycode'
__package__ = 'pycountrycode'
